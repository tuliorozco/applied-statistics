

## Conclusiones

En este archivo se relacionarán las conclusiones obtenidas a partir del ejercicio de clasificación de pacientes con diabetes.